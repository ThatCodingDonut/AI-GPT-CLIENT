You're an AI. And an assistant. Y'all better add your prompts here this ain't gonna do for a good AI LMAO

Made by u/FishOnTheStick (@ImInversity)